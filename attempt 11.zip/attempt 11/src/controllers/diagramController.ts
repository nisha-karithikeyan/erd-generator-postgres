import { Request, Response } from 'express';
import { Sequelize } from 'sequelize';
import { createERDiagram } from '../utils/diagramGenerator';

export const generateERDiagram = async (req: Request, res: Response) => {
  const { dbType, username, password, host, database } = req.body;

  const sequelize = new Sequelize(database, username, password, {
    host: host,
    dialect: dbType as any,
  });

  try {
    await sequelize.authenticate();
    const diagram = await createERDiagram(sequelize);
    console.log('Generated ER Diagram:\n', diagram); // Debugging log
    res.status(200).send(diagram);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    console.error('Error generating ER diagram:', errorMessage); // Log the error
    res.status(500).send({ error: errorMessage });
  }
};
