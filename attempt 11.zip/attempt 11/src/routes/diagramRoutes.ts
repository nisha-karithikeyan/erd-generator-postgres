import { Router } from 'express';
import { generateERDiagram } from '../controllers/diagramController';

const router = Router();

router.post('/generate', generateERDiagram);

export default router;
