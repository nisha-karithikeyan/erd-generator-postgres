import { Sequelize, QueryTypes } from 'sequelize';

export const createERDiagram = async (sequelize: Sequelize) => {
  const queryInterface = sequelize.getQueryInterface();

  const tablesQuery = `
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'public'
  `;

  const tables: { table_name: string }[] = await sequelize.query(tablesQuery, {
    type: QueryTypes.SELECT,
  });

  let mermaidDiagram = 'erDiagram\n';

  for (const table of tables) {
    if (table && typeof table.table_name === 'string') {
      const tableName = table.table_name;
      const columns = await queryInterface.describeTable(tableName);

      const escapedTableName = tableName.replace(/[^a-zA-Z0-9_]/g, '_');

      mermaidDiagram += `${escapedTableName} {\n`;
      for (const column in columns) {
        const escapedColumn = column.replace(/[^a-zA-Z0-9_]/g, '_');
        const columnType = columns[column].type.replace(/[^a-zA-Z0-9_]/g, '_');
        mermaidDiagram += `  ${escapedColumn} ${columnType}\n`;
      }
      mermaidDiagram += '}\n';
    }
  }

  const foreignKeysQuery = `
    SELECT 
      tc.table_name AS table_name,
      kcu.column_name AS column_name,
      ccu.table_name AS foreign_table_name,
      ccu.column_name AS foreign_column_name
    FROM 
      information_schema.table_constraints AS tc 
      JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
      JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
    WHERE constraint_type = 'FOREIGN KEY'
  `;

  const foreignKeys: {
    table_name: string,
    column_name: string,
    foreign_table_name: string,
    foreign_column_name: string
  }[] = await sequelize.query(foreignKeysQuery, {
    type: QueryTypes.SELECT,
  });

  for (const fk of foreignKeys) {
    const escapedTableName = fk.table_name.replace(/[^a-zA-Z0-9_]/g, '_');
    const escapedColumnName = fk.column_name.replace(/[^a-zA-Z0-9_]/g, '_');
    const escapedForeignTableName = fk.foreign_table_name.replace(/[^a-zA-Z0-9_]/g, '_');
    const escapedForeignColumnName = fk.foreign_column_name.replace(/[^a-zA-Z0-9_]/g, '_');

    mermaidDiagram += `${escapedTableName} }o--|| ${escapedForeignTableName} : "${escapedColumnName} to ${escapedForeignColumnName}"\n`;
  }

  return mermaidDiagram;
};
